
public class StartView extends View{
	public StartView(int frameHeight, int frameWidth) {
		super(frameHeight,frameWidth);
	}
	public void paint() {}
	public void update() {}
}
