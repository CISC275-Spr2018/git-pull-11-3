
public class Controller {
	private Model model;
	private View view;
	public Controller(Model model, View view) {
		this.model=model;
		this.view=view;
	}
	public void start() {}
	public void boatChoice() {}
	public void arrowKeyListener() {}
	public void answerChoiceListener() {}
	public void addTime() {}
	public void addPlants() {}
	public void slowErosion() {}
	public void slowSpeed() {}
	public void countDown() {}
	public void turnBoatAround() {}
	public void checkPoints() {}
}
