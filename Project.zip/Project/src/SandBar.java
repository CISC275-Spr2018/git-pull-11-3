
public class SandBar extends estuaryGamePiece{
	public SandBar(int Xloc, int Yloc, int xSize, int ySize) {
		super(Xloc, Yloc, xSize, ySize);
	}
	public void createRandomSandBar() {}
	@Override
	public boolean hasCollide() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void create() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
}
