
public abstract class estuaryGamePiece {
	private int Xloc;
	private int Yloc;
	private int xSize;
	private int ySize;
	public estuaryGamePiece(int Xloc,int Yloc,int xSize,int ySize) {
		this.Xloc=Xloc;
		this.Yloc=Yloc;
		this.xSize=xSize;
		this.ySize=ySize;
	}
	public void onCollide() {};
	public abstract boolean hasCollide() {}
	public abstract void create();
	public abstract void update();
	public abstract void destroy();
}
