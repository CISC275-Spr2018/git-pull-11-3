
public class Buoy extends estuaryGamePiece{
	public Buoy(int Xloc, int Yloc, int xSize, int ySize) {
		super(Xloc, Yloc, xSize, ySize);
	}

	@Override
	public boolean hasCollide() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void create() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
}
