
public class Plant extends estuaryGamePiece {
	public Plant(int Xloc, int Yloc, int xSize, int ySize) {
		super(Xloc, Yloc, xSize, ySize);
	}
	public void setSlowErosion() {}
	public void grow() {}
	@Override
	public boolean hasCollide() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void create() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
}
