
public class infoBubble extends textBubble {
	public infoBubble(String text, int Xloc, int Yloc, int XSize, int YSize) {
		super(text, Xloc, Yloc, XSize, YSize);
	}
}
