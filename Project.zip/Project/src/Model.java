import java.awt.event.KeyAdapter;

public class Model extends KeyAdapter{
	private Estuary estuary;
	private SandBar sandbar;
	private Vessel vessel;
	private Buoy buoy;
	private Plant plant;
	private textBubble textbubble;
	public Model() {}
}
