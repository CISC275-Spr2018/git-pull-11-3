
public class choiceView extends View{
	public choiceView(int imageHeight, int imageWidth) {
		super(imageHeight, imageWidth);
	}
	public void paint() {}
	public void createImage() {}
	public void update() {}
	public void displayboats() {}
}
