
public interface collidable {
	public static void onCollide() {}
}
