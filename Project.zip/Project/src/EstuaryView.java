
public class EstuaryView extends View{
	public EstuaryView(int imageHeight, int imageWidth) {
		super(imageHeight, imageWidth);
	}
	public void paint() {}
	public void createImage() {}
	public void update() {}
}
