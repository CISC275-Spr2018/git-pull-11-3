
public class questionBubble extends textBubble {
	public questionBubble(String text, int Xloc, int Yloc, int XSize,int YSize) {
		super(text, Xloc, Yloc, XSize, YSize);
	}
	public boolean answerCorrectly() {}
}
