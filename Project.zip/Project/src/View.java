
public class View {
	private int imageHeight;
	private int imageWidth;
	public View(int imageHeight, int imageWidth) {
		this.imageHeight=imageHeight;
		this.imageWidth=imageWidth;
	}
}
