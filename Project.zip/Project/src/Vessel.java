
public abstract class Vessel extends estuaryGamePiece{
	private int speed;
	private int turning;
	private int wakeHeight;
	public Vessel(int Xloc, int Yloc, int xSize, int ySize) {
		super(Xloc, Yloc, xSize, ySize);
	}	
	
}
